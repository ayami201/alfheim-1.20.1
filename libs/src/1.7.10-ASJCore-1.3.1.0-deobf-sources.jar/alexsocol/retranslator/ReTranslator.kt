//@file:Suppress("UNUSED_PARAMETER")
//
//package alexsocol.retranslator
//
//import alexsocol.asjlib.*
//import alexsocol.asjlib.extendables.ASJConfigHandler
//import alexsocol.patcher.KotlinAdapter
//import alexsocol.retranslator.RTMain.MODID
//import alexsocol.retranslator.RTMain.targetLanguage
//import com.google.gson.JsonParser
//import cpw.mods.fml.common.Mod
//import cpw.mods.fml.common.event.FMLPreInitializationEvent
//import cpw.mods.fml.relauncher.FMLRelaunchLog
//import cpw.mods.fml.relauncher.IFMLLoadingPlugin.MCVersion
//import gloomyfolken.hooklib.asm.*
//import gloomyfolken.hooklib.minecraft.HookLoader
//import net.minecraft.client.resources.*
//import net.minecraft.util.*
//import net.minecraftforge.common.config.Configuration
//import java.io.File
//import java.net.*
//import java.nio.charset.Charset
//import java.util.*
//
//@MCVersion("1.7.10")
//class RTHookLoader: HookLoader() {
//
//	override fun registerHooks() {
//		FMLRelaunchLog.info("[ReTranslator] Loaded coremod. Registering hooks...")
//
//		registerHookContainer("alexsocol.retranslator.RTHookHandler")
//	}
//}
//
//object RTHookHandler {
//
//	@Hook(returnCondition = ReturnCondition.ALWAYS, injectOnExit = true)
//	@JvmStatic
//	fun translateToLocal(static: StatCollector?, key: String, @Hook.ReturnValue result: String): String {
//		if (ASJUtilities.isServer) return result
//
//		return HackI18n.translateToLocal(key, result)
//	}
//
//	@Hook(returnCondition = ReturnCondition.ALWAYS, injectOnExit = true)
//	@JvmStatic
//	fun translateToLocalFormatted(static: StatCollector?, key: String, vararg format: Any, @Hook.ReturnValue result: String): String {
//		if (ASJUtilities.isServer) return result
//
//		return HackI18n.translateToLocalFormatted(key, format, result)
//	}
//
//	@Hook(returnCondition = ReturnCondition.ALWAYS, injectOnExit = true)
//	@JvmStatic
//	fun format(static: I18n?, key: String, vararg format: Any, @Hook.ReturnValue result: String): String {
//		if (ASJUtilities.isServer) return result
//
//		return HackI18n.translateToLocalFormatted(key, format, result)
//	}
//}
//
//object RTConfigHandler: ASJConfigHandler() {
//
//	private var _translator = "GOOGLE"
//	val translator get() = EnumTranslationServiceType.valueOf(_translator)
//	var modMainLanguages = HashMap<String, String>()
//
//	override fun readProperties() {
//		loadProp(Configuration.CATEGORY_GENERAL, "translator", _translator, true, "Translation service (one of: ${EnumTranslationServiceType.entries.joinToString { it.name }})")
//		loadProp(Configuration.CATEGORY_GENERAL, "modMainLanguages", emptyArray<String>(), true, "Array of mod main languages in for of \"modid:lang\" (example: \"retranslator:en_US\"). If not specified for any mod, defaults to en_US", false).forEach {
//			val (modid, lang) = it.split(":")
//			modMainLanguages[modid] = lang
//		}
//	}
//}
//
//@Mod(modid = MODID, modLanguageAdapter = KotlinAdapter.className)
//object RTMain {
//
//	const val MODID = "retranslator"
//	lateinit var targetLanguage: String
//
//	@Mod.EventHandler
//	fun preInit(e: FMLPreInitializationEvent) {
//		RTConfigHandler.loadConfig(e.suggestedConfigurationFile)
//		ASJUtilities.log("[$MODID] Found main mod lang overrides for next domains: [${RTConfigHandler.modMainLanguages.entries.joinToString { (k, v) -> "$k -> $v" }}]")
//
//		targetLanguage = mc.gameSettings.language
//		HackI18n.init()
//	}
//}
//
//object HackI18n {
//
//	val keysMap = HashMap<String, String>()
//	var initialized = false
//
//	fun init() {
//		initialized = true
//
//		mc.resourceManager.resourceDomains.forEach { domain ->
//			domain as String
//
//			try_ {
//				ASJUtilities.log("[$MODID] Parsing target $targetLanguage lang for $domain")
//
//				mc.resourceManager.getAllResources(ResourceLocation(domain, "lang/$targetLanguage.lang")).forEach { res ->
//					res as IResource
//					try_ {
//						val tempMap = HashMap<String, String>()
//						CacheHandler.readLangFromLinesToMap(res.inputStream.reader().readLines(), tempMap)
//
//						tempMap.forEach { (key, value) ->
//							keysMap[key] = value
//						}
//					}
//				}
//			}
//
//			try_ {
//				val modMainLang = RTConfigHandler.modMainLanguages[domain] ?: "en_US"
//
//				ASJUtilities.log("[$MODID] Parsing main $modMainLang lang for $domain")
//
//				val resources = mc.resourceManager.getAllResources(ResourceLocation(domain, "lang/$modMainLang.lang"))
//				resources.forEachIndexed { id, res -> res as IResource
//					try_ {
//						val tempMap = HashMap<String, String>()
//						CacheHandler.readLangFromLinesToMap(res.inputStream.reader().readLines(), tempMap)
//
//						var parsed = 0
//
//						tempMap.forEach { (key, value) ->
//							if (key !in keysMap || keysMap[key] == value)
//								keysMap[key] = if (modMainLang == targetLanguage) value else translate(key, value, modMainLang) ?: value
//
//							if (++parsed % 100 == 0)
//								ASJUtilities.log("[$MODID] Parsed $parsed/${tempMap.size} entries in $id/${resources.size} resource...")
//						}
//					}
//				}
//			}
//		}
//	}
//
//	fun translateToLocal(key: String, result: String): String {
//		if (!initialized || keysMap[key] == result) return result
//
//		return translate(key) ?: result
//	}
//
//	fun translateToLocalFormatted(key: String, format: Array<out Any>, result: String): String {
//		if (!initialized || keysMap[key]?.safeFormat(*format) == result) return result
//
//		return translate(key)?.safeFormat(*format) ?: result
//	}
//
//	private fun translate(key: String, value: String? = null, sourceLang: String? = null): String? {
//		val cached = CacheHandler[key]
//		if (cached != null) return cached
//
//		val toTranslate = (value ?: keysMap[key]) ?: return null
//		val translated = RTConfigHandler.translator.ts.translate(toTranslate, sourceLang) ?: return null
//
//		CacheHandler[key] = translated
//		return translated
//	}
//
//	private fun String.safeFormat(vararg args: Any?): String {
//		return if (args.isEmpty()) this else try {
//			format(*args)
//		} catch (e: IllegalFormatException) {
//			this
//		}
//	}
//}
//
//object CacheHandler {
//
//	val cacheMaps = HashMap<String, HashMap<String, String>>()
//	val cacheFile get() = File("ReTranslatorCache/${targetLanguage}.lang").apply {
//		if (!exists()) parentFile.mkdirs()
//		createNewFile()
//	}
//
//	init {
//		// Load cache from file into memory during initialization
//		readLangFromLinesToMap(cacheFile.readLines(), cacheMaps.computeIfAbsent(targetLanguage) { HashMap() })
//	}
//
//	operator fun get(key: String): String? {
//		val cacheMap = cacheMaps.computeIfAbsent(targetLanguage) { HashMap() }
//
//		// Check if the key exists in RAM cache
//		if (cacheMap.containsKey(key)) {
//			return cacheMap[key]
//		}
//
//		// If not in RAM cache, try to load from file
//		val value = loadFromCacheFile(key)
//		if (value != null) {
//			// If found in file, add to RAM cache for quick retrieval next time
//			cacheMap[key] = value
//		}
//		return value
//	}
//
//	operator fun set(key: String, value: String) {
//		// Update RAM cache
//		cacheMaps.computeIfAbsent(targetLanguage) { HashMap() }[key] = value
//		// Update cache file
//		cacheFile.appendText("$key=$value\n")
//	}
//
//	private fun loadFromCacheFile(key: String): String? {
//		val line = cacheFile.readLines().find { it.startsWith("$key=") } ?: return null
//		return line.split("=", limit = 2).getOrNull(1)
//	}
//
//	fun readLangFromLinesToMap(lines: List<String>, map: HashMap<String, String>) {
//		lines.forEach { line ->
//			if (line.startsWith("#") || line.isEmpty()) return@forEach
//			val splitted = line.split("=", limit = 2)
//			if (splitted.size != 2) return@forEach
//
//			map[splitted[0]] = splitted[1]
//		}
//	}
//}
//
//enum class EnumTranslationServiceType(val ts: TranslationService) {
//	GOOGLE(GoogleTranslationService);
//}
//
//abstract class TranslationService {
//
//	val parser = JsonParser()
//
//	abstract fun translate(text: String, sourceLang: String?): String?
//}
//
//object GoogleTranslationService: TranslationService() {
//
//	const val URL = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=%s&tl=%s&dt=t&dt=bd&dj=1&q=%s"
//
//	override fun translate(text: String, sourceLang: String?): String? {
//		return try {
//			parser.parse(URL(URL.format(sourceLang ?: "auto", targetLanguage, URLEncoder.encode(text, "UTF-8").replace("+", "%20"))).openStream().use {it.readBytes().toString(Charset.defaultCharset())}).asJsonObject["sentences"].asJsonArray.joinToString("") { it.asJsonObject["trans"].asString }.replace("\u200B", "")
//		} catch (e: Throwable) {
//			null
//		}
//	}
//}