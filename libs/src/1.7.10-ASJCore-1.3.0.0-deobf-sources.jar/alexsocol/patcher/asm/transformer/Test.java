package alexsocol.patcher.asm.transformer;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFurnace;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.ChunkCoordinates;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Test {
	protected World worldObj;
	public int xCoord;
	public int yCoord;
	public int zCoord;
	private ArrayList<ChunkCoordinates> pedestals = new ArrayList();
	private int dangerCount = 0;
	public boolean active = false;
	public boolean crafting = false;
	public boolean checkSurroundings = true;
	public int symmetry = 0;
	public int instability = 0;
	private ArrayList<ItemStack> recipeIngredients = null;
	private Object recipeOutput = null;
	private String recipePlayer = null;
	private String recipeOutputLabel = null;
	private ItemStack recipeInput = null;
	private int recipeInstability = 0;
	private int recipeXP = 0;
	private int recipeType = 0;
	public int count = 0;
	public int craftCount = 0;
	public float startUp;
	private int countDelay = 10;
	ArrayList<ItemStack> ingredients = new ArrayList();
	int itemCount = 0;
	
	private void getSurroundings() {
		ArrayList<ChunkCoordinates> stuff = new ArrayList();
		this.pedestals.clear();
		
		try {
			boolean skip;
			int yy;
			int x;
			int y;
			int z;
			for(int xx = -12; xx <= 12; ++xx) {
				for(int zz = -12; zz <= 12; ++zz) {
					skip = false;
					
					for(yy = -5; yy <= 10; ++yy) {
						if (xx != 0 || zz != 0) {
							x = this.xCoord + xx;
							y = this.yCoord - yy;
							z = this.zCoord + zz;
							TileEntity te = this.worldObj.getTileEntity(x, y, z);
							if (!skip && yy > 0 && Math.abs(xx) <= 8 && Math.abs(zz) <= 8 && te instanceof TileEntityFurnace) {
								this.pedestals.add(new ChunkCoordinates(x, y, z));
								skip = true;
							} else {
								Block bi = this.worldObj.getBlock(x, y, z);
								if (bi == Blocks.skull || bi instanceof BlockFurnace) {
									stuff.add(new ChunkCoordinates(x, y, z));
								}
							}
						}
					}
				}
			}
			
			this.symmetry = 0;
			Iterator i$ = this.pedestals.iterator();
			
			int xx;
			while(i$.hasNext()) {
				ChunkCoordinates cc = (ChunkCoordinates)i$.next();
				skip = false;
				yy = this.xCoord - cc.posX;
				x = this.zCoord - cc.posZ;
				TileEntity te = this.worldObj.getTileEntity(cc.posX, cc.posY, cc.posZ);
				if (te instanceof TileEntityFurnace) {
					this.symmetry += 2;
					if (((TileEntityFurnace)te).getStackInSlot(0) != null) {
						++this.symmetry;
						skip = true;
					}
				}
				
				z = this.xCoord + yy;
				xx = this.zCoord + x;
				te = this.worldObj.getTileEntity(z, cc.posY, xx);
				if (te instanceof TileEntityFurnace) {
					this.symmetry -= 2;
					if (((TileEntityFurnace)te).getStackInSlot(0) != null && skip) {
						--this.symmetry;
					}
				}
			}
			
			float sym = 0.0F;
			i$ = stuff.iterator();
			
			while(true) {
				ChunkCoordinates cc;
				Block bi;
				do {
					if (!i$.hasNext()) {
						this.symmetry = (int)((float)this.symmetry + (sym / 10F));
						return;
					}
					
					cc = (ChunkCoordinates)i$.next();
					x = this.xCoord - cc.posX;
					y = this.zCoord - cc.posZ;
					bi = this.worldObj.getBlock(cc.posX, cc.posY, cc.posZ);
					if (bi == Blocks.skull) {
						sym += 1F;
					}
					
					xx = this.xCoord + x;
					int zz = this.zCoord + y;
					bi = this.worldObj.getBlock(xx, cc.posY, zz);
				} while(bi != Blocks.skull);
				
				sym -= 2F;
			}
		} catch (Exception var11) {
		}
	}
}
